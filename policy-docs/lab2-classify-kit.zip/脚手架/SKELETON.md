# SKELETON · 最小实现骨架说明

> 本材料为培训教学合成的虚构材料，企业与人员均为化名，条文与数值为教学示意，不对应任何真实机构、制度或业务数据；实务请以现行有效规定为准。

**定位**：这是"施工"环节的落点说明——只给**三个工具函数签名**和**一个人工确认点的伪代码**，不给完整实现。
**学员任务**：照着签名把三个工具接上（在线走模型服务，离线走 `离线兜底包/stub_tools.py`），再把人工确认点接进主链路。
**原则**：契约字段照本文，运行机制按需实现；**课堂只强制要求保留"人工确认点"**。

---

## 1. 三个工具函数签名

### 1.1 `classify_request`

```python
def classify_request(request_text: str) -> dict:
    """
    诉求分类（五类）。

    输入:
        request_text: 客户诉求全文（不是关键词）

    输出:
        {
          "category": str,            # 业务办理/电费与计量/故障报修与停电/投诉举报与用电安全/其他
          "confidence": float,        # 启发式不确定性信号，不作为校准概率
          "reason": str,              # 判定依据（引用定义，不复述原文）
          "needs_human_review": bool, # confidence < 0.6 或非法类别 ⇒ True
          "status": str               # success / insufficient / error
        }

    硬边界:
        - 可选辅助，不得成为所有任务的固定入口；
        - 拿不准 ⇒ needs_human_review=True，不硬归"其他"；
        - 返回非法类别 ⇒ 调用方必须兜底转人工。
    """
```

### 1.2 `search_policy`

```python
def search_policy(question: str) -> dict:
    """
    知识文档检索问答。

    输入:
        question: 政策问题（单条款锚定）

    输出:
        {
          "answer": str,              # 答复文本；数值须标注"（教学示意值）"
          "evidence": [               # 无证据时为空列表
              {"document": str, "article": str, "excerpt": str}
          ],
          "evidence_sufficient": bool,
          "status": str               # success / not_found / error
        }

    硬边界:
        - 无证据必须 not_found，不得编造条款号或数值；
        - 程序性条款（负责解释/施行日期/有效期）不得作为业务依据；
        - document 写文件名，article 写"第X条"。
    """
```

### 1.3 `query_department`

```python
def query_department(request_text: str, category: str = None) -> dict:
    """
    专业职责归属查询。

    输入:
        request_text: 诉求全文（不是单个关键词）
        category:     可选，五类之一，用于消歧

    输出:
        {
          "primary_department": str,          # 跨专业协同档必须非空
          "collaborating_departments": [str],
          "responsibility_basis": str,        # 命中的职责关键词
          "confidence": float,
          "status": str                       # success / not_found / ambiguous
        }

    硬边界:
        - 不得绕过工具凭记忆猜部门；
        - 无匹配 not_found；多项冲突 ambiguous；两种情况都转人工。
    """
```

> **六条线**（`职责库/departments.csv`）：客户服务中心、营销部、计量中心、运维检修部、调度控制中心、安全监察部。

---

## 2. 人工确认点伪代码

命中敏感 或 证据不足 → **暂停并请人工三选一**。关键是 `interrupted = true` 之后**真的停住**。

```python
def request_human_review(reason, known_facts, evidence, recommended_next_step):
    """返回 review_task，并置 interrupted=True —— 调用方必须立即停止后续自动流程。"""
    return {
        "review_task": {
            "reason": reason,
            "known_facts": known_facts,
            "evidence": evidence,
            "recommended_next_step": recommended_next_step,
        },
        "interrupted": True,   # 敏感/冲突/高风险必须真暂停
    }


def handle_request(request_text):
    trace = []

    # ---- 环节 A：分类（可选辅助） ----
    cls = classify_request(request_text)
    trace.append(("classify_request", request_text, cls))

    # ---- 环节 B：检索 ----
    policy = search_policy(request_text)

    # ---- 环节 C：判档（按动作，不按字面词） ----
    hit_sensitive, sensitive_item = detect_sensitive(request_text)   # 见《敏感清单》
    need_department = needs_routing_by_duty(request_text, cls)       # 需查职责归属即算

    # ---- 环节 D：人工确认点（先于一切自动动作判定） ----
    if hit_sensitive or not policy["evidence_sufficient"] or cls["needs_human_review"]:
        reason = sensitive_item or ("证据不足" if not policy["evidence_sufficient"]
                                    else "分类置信度低")
        review = request_human_review(
            reason=reason,
            known_facts=[request_text],
            evidence=policy.get("evidence", []),
            recommended_next_step="请人工决定：批准处置建议 / 要求补充材料 / 终止自动处理",
        )
        trace.append(("request_human_review", reason, review))
        print("暂停，请求人工审核：", reason)
        print("人工请三选一：1. 批准处置建议 2. 要求补充材料 3. 终止自动处理")
        return {"action": "转人工", "interrupted": True, "trace": trace}   # ← 真停：直接返回，不再往下走

    # ---- 环节 E：按档位分支 ----
    if need_department:
        dept = query_department(request_text, cls["category"])
        if dept["status"] != "success":          # not_found / ambiguous
            return handle_request_human_review(dept, trace)              # 同样真停
        draft = create_workorder_draft(
            request_summary=request_text,
            category=cls["category"],
            department=dept["primary_department"],
            policy_evidence=policy["evidence"],
            proposed_action="转 " + dept["primary_department"] + " 处理",
        )                                        # draft["submitted"] 恒为 False
        trace.append(("create_workorder_draft", request_text, draft))
        return {"action": "深度处理", "draft": draft, "trace": trace}

    # ---- 咨询档：自动答复 ----
    trace.append(("auto_reply", request_text, policy["answer"]))
    return {"action": "自动答复", "reply_ok": True, "answer": policy["answer"], "trace": trace}
```

**三处必须真停**：1. 命中敏感；2. 证据不足（`not_found`）；3. 分类低置信（`confidence < 0.6`）。
**假暂停的判定**：打印"已转人工"之后仍生成答复或工单草稿，一律不合格。

---

## 3. 运行命令示例

### 3.1 离线路径（无网络也能跑，课堂兜底）

```bash
cd 离线兜底包

# 工具自测：8 条固定用例，全部断言通过才退出码 0
python stub_tools.py

# 内置样例（咨询档）→ 自动答复
python run_offline_demo.py

# 指定诉求（含空格要加引号）
python run_offline_demo.py "我想申请居民新装电表 需要什么材料"

# 跨专业协同档 → 查职责 + 工单草稿（submitted=False）
python run_offline_demo.py "企业要做增容报装 涉及哪些环节 要不要调度配合"

# 敏感档 → 暂停，请求人工审核并结束
python run_offline_demo.py "我实名举报一家企业私自增容窃电 要求查处并反馈结果"
python run_offline_demo.py "反映小区配电房长期堆放杂物 存在严重安全隐患"

# 库外问题 → 拒答
python run_offline_demo.py "我家燃气灶点不着火该找谁修"
```

### 3.2 在线路径（模型服务可用时）

```bash
# 1) 用启动提示词驱动 Agent（从 office-hours 开始，一环一停）
#    提示词见 脚手架/启动提示词-模板.md
# 2) 按 SPEC 实现三个工具，逐环节落盘
# 3) 跑验收命令（见 脚手架/AGENTS.md 第 3 节）
python -c "import json;json.load(open('评测集/development_tasks.json',encoding='utf-8'));print('json ok')"
```

### 3.3 期望输出判据

| 样例 | 期望 `action` | 期望关键字段 |
|---|---|---|
| 居民新装电表需要什么材料 | 深度处理（或咨询，取决于是否需查职责） | 草稿 `submitted=False` |
| 企业增容报装 | 深度处理 | `primary_department=营销部`；协同含调度控制中心 |
| 实名举报窃电要求查处 | **转人工** | `interrupted=True`；打印"暂停，请求人工审核" |
| 配电房堆物严重安全隐患 | **转人工** | `interrupted=True` |
| 燃气灶点不着火（库外） | **转人工** | 先拒答 `answer` ＝"知识库中未找到，建议咨询人工"，随后 `request_human_review`、`interrupted=True` |

---

## 4. 从骨架到可演示：施工顺序建议

1. 先接 `search_policy`（最容易验证，有 6 条验证集）；
2. 再接 `query_department`（6 行职责库，规则清晰）；
3. 最后接 `classify_request`（无标注数据，走零样本，最后调阈值）；
4. **人工确认点必须在第 1 步就接上**，不要等功能齐了再补——假阴性是底线问题；
5. 每接完一个工具，跑一次 `python stub_tools.py` 与对应样例，**一环一停**，汇报后再往下。
